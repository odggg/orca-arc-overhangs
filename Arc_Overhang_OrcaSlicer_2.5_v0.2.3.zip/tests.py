import sys
from pathlib import Path
import unittest
import tempfile
from unittest.mock import patch
ROOT = Path(__file__).parent
sys.path[:0] = [str(ROOT / "test-deps"), str(ROOT / "dist"), str(ROOT / "plugin")]
import arc_overhang as a

def ring(x0, y0, x1, y1, role="Outer wall"):
    return f"; FEATURE: {role}\nG1 X{x0} Y{y0} F1800\nG1 X{x1} Y{y0} E0.5\nG1 X{x1} Y{y1} E0.5\nG1 X{x0} Y{y1} E0.5\nG1 X{x0} Y{y0} E0.5\n"

def fixture(style="modern"):
    header = "G90\nM83\nG92 E0\n; nozzle_diameter = 0.4\n; filament_diameter = 1.75\n; layer_height = 0.2\n; outer_wall_line_width = 0.42\n"
    text = header + "; CHANGE_LAYER\nG1 Z0.2\n" + ring(10, 10, 20, 30)
    text += "; CHANGE_LAYER\nG1 Z0.4\n" + ring(10, 10, 30, 30)
    text += "; FEATURE: Overhang wall\nG1 X30 Y10\nG1 X30 Y30 E0.5\n"
    text += "; FEATURE: Bridge\nG1 X19 Y10.5 F1800\n"
    for i in range(48):
        y = 10.5 + i * 0.4
        xa, xb = (19, 29.5) if i % 2 == 0 else (29.5, 19)
        text += f"G1 X{xa} Y{y} F1800\nG1 X{xb} Y{y} E0.15 F1200\n"
    text += "; FEATURE: Sparse infill\nG1 X12 Y12 F9000\nG1 X15 Y15 E0.3 F2400\nM106 P2 S120\n"
    if style == "legacy":
        text = text.replace("; CHANGE_LAYER", ";LAYER_CHANGE").replace("; FEATURE: ", ";TYPE:")
    return text

class Tests(unittest.TestCase):
    def test_configuration_rejects_invalid(self):
        for cfg in ({"arc_speed_mm_s": 0}, {"points_per_circle": 81}, {"enabled": 1}, {"flow_multiplier": float("nan")}, {"made_up": 1}, {"max_centers": 1.5}):
            with self.subTest(cfg=cfg), self.assertRaises(ValueError):
                a.configuration(cfg)

    def test_modern_and_legacy_arcs_and_idempotence(self):
        for style in ("modern", "legacy"):
            with self.subTest(style=style):
                source = fixture(style)
                output, report = a.process_text(source, {"minimum_coverage_percent": 80})
                self.assertEqual(report["replaced_features"], 1, report)
                self.assertGreater(report["generated_arcs"], 5)
                self.assertIn(a.MARKER, output)
                self.assertTrue(output.endswith(source[source.index("; FEATURE: Sparse"):] if style == "modern" else source[source.index(";TYPE:Sparse"):]))
                self.assertEqual(a.process_text(output)[0], output)
                original_end = a.parse(source.splitlines(True))[-1].moves[-1].after
                new_end = a.parse(output.splitlines(True))[-1].moves[-1].after
                self.assertAlmostEqual(original_end.e, new_end.e, places=6)
                self.assertEqual(a.replace(original_end, e=0), a.replace(new_end, e=0))
                self.assertNotIn("nan", output.lower())
                self.assertNotIn("inf ", output.lower())

    def test_no_bridge_unchanged(self):
        source = "G90\nM83\n; CHANGE_LAYER\nG1 X1 Y1 E0.2\n"
        self.assertEqual(a.process_text(source)[0], source)

    def test_absolute_e_rejected(self):
        source = fixture().replace("M83", "M82")
        with self.assertRaises(a.UnsupportedGCode):
            a.process_text(source)

    def test_fully_supported_bridge_with_overhang_tag_is_preserved(self):
        source = fixture().replace(ring(10, 10, 20, 30), ring(10, 10, 30, 30), 1)
        output, report = a.process_text(source)
        self.assertEqual(report["replaced_features"], 0)
        self.assertEqual(report["skipped_features"], 1)
        self.assertNotIn(a.MARKER, output)
        self.assertEqual(output, source)

    def test_arc_paths_start_on_support_or_previous_arc(self):
        support = a.Polygon([(0, 0), (1, 0), (1, 1), (0, 1)])
        disconnected = a.LineString([(8, 0.5), (9, 0.5)])
        bridge = a.LineString([(1, 0.5), (2, 0.5)])
        continuation = a.LineString([(3, 0.5), (2, 0.5)])
        ordered = a.anchor_arc_paths(
            [continuation, bridge], support, 0.4, 0.42)
        self.assertIsNotNone(ordered)
        self.assertEqual(list(ordered[0].coords)[0], (1.0, 0.5))
        self.assertEqual(list(ordered[1].coords)[0], (2.0, 0.5))
        self.assertIsNone(a.anchor_arc_paths(
            [disconnected], support, 0.4, 0.42))
        self.assertIsNone(a.anchor_arc_paths(
            [bridge, disconnected], support, 0.4, 0.42))

    def test_wall_overlap_is_zero_when_disabled_and_grows_with_setting(self):
        self.assertEqual(a.DEFAULTS["wall_overlap_mm"], 0.2)
        source = fixture()
        printer = a.printer_settings(source.splitlines())
        width = printer["outer_wall_line_width"]
        arc_width = printer["nozzle_diameter"] * a.DEFAULTS["arc_spacing_nozzle_ratio"]
        current = a.layer_shape([f for f in a.parse(source.splitlines(True)) if f.layer == 1], width)
        wall_footprint = current.boundary.buffer(width / 2)
        measured = []
        for overlap in (0.0, 0.2, 0.8):
            output, report = a.process_text(source, {
                "wall_overlap_mm": overlap,
                "minimum_coverage_percent": 80,
            })
            self.assertEqual(report["replaced_features"], 1, report)
            arcs = [a.segment(move) for feature in a.parse(output.splitlines(True))
                    if feature.role in ("bridge", "bridge infill", "internal bridge")
                    for move in feature.moves if a.segment(move) is not None]
            arc_footprint = a.unary_union([line.buffer(arc_width / 2) for line in arcs])
            measured.append(arc_footprint.intersection(wall_footprint).area)
        self.assertLess(measured[0], 1e-6, measured)
        self.assertLess(measured[1], measured[2], measured)

    def test_geometric_overhang_without_special_wall_tag(self):
        source = fixture().replace("Overhang wall", "Inner wall")
        output, report = a.process_text(source)
        self.assertEqual(report["replaced_features"], 1)
        self.assertIn(a.MARKER, output)

    def test_disabled_unchanged(self):
        source = fixture()
        self.assertEqual(a.process_text(source, {"enabled": False})[0], source)

    def test_cancellation(self):
        with self.assertRaises(a.Cancelled):
            a.process_text(fixture(), cancelled=lambda: True)

    def test_unreachable_area_preserved(self):
        source = fixture().replace(ring(10, 10, 20, 30), ring(100, 100, 110, 120), 1)
        self.assertEqual(a.process_text(source)[0], source)

    def test_holes_in_shape(self):
        source = "G90\nM83\n; CHANGE_LAYER\nG1 Z0.2\n" + ring(0, 0, 20, 20) + ring(5, 5, 10, 10)
        shape = a.layer_shape(a.parse(source.splitlines(True)), 0.42)
        self.assertAlmostEqual(shape.area, 375)
        self.assertFalse(shape.contains(a.Point(7, 7)))

    def test_file_atomic_failure_and_binary(self):
        with tempfile.TemporaryDirectory(dir=ROOT) as folder:
            path = Path(folder) / "test.gcode"
            source = fixture().encode()
            path.write_bytes(source)
            with patch.object(a.os, "replace", side_effect=OSError("test failure")):
                with self.assertRaises(OSError):
                    a.process_file(path, {"minimum_coverage_percent": 80})
            self.assertEqual(path.read_bytes(), source)
            self.assertEqual(list(Path(folder).glob(".arc-overhang-*")), [])
            path.write_bytes(b"PK\\0binary")
            with self.assertRaises(a.UnsupportedGCode):
                a.process_file(path)

    def test_speed_spacing_wall_overlap_independent(self):
        cfg = a.configuration({"arc_speed_mm_s": 10, "minimum_arc_speed_mm_s": 10,
                               "arc_spacing_nozzle_ratio": 0.5, "wall_overlap_mm": 1.2})
        printer = a.printer_settings(fixture().splitlines())
        params = a.parameters(cfg, printer, lambda:False)
        self.assertEqual(params["ArcWidth"], 0.2)
        out = "".join(a.emit_arcs([a.LineString([(20,20),(22,20)])], a.State(x=20,y=20,relative_e=True),
                         a.State(x=22,y=20,relative_e=True), cfg, printer))
        self.assertIn("G1 F600.00", out)
        self.assertIn("E0.1410612", out)


    def test_split_outer_overhang_wall_ring(self):
        source = "G90\nM83\n; CHANGE_LAYER\nG1 Z0.2\n"
        source += "; FEATURE: Outer wall\nG1 X0 Y0\nG1 X20 Y0 E1\nG1 X20 Y20 E1\n"
        source += "; FEATURE: Overhang wall\nG1 X0 Y20 E1\nG1 X0 Y0 E1\n"
        shape = a.layer_shape(a.parse(source.splitlines(True)), 0.42)
        self.assertAlmostEqual(shape.area, 400)

    def test_other_bridge_in_same_layer_is_preserved(self):
        interior = "; FEATURE: Bridge\nG1 X12 Y12 F1800\nG1 X14 Y12 E0.1\nG1 X14 Y13 E0.1\nG1 X12 Y13 E0.1\n"
        source = fixture() + interior
        output, report = a.process_text(source)
        self.assertEqual(report["replaced_features"], 1)
        self.assertEqual(report["skipped_features"], 1)
        self.assertTrue(output.endswith(interior))

    def test_default_coverage_and_toolpath_envelope(self):
        output, report = a.process_text(fixture())
        self.assertEqual(report["replaced_features"], 1)
        self.assertGreaterEqual(report["minimum_coverage_percent"], 90)
        injected = output.split(a.MARKER + "BEGIN")[1].split(a.MARKER + "END")[0]
        for _, words in (a.command(line) for line in injected.splitlines()):
            if "X" in words:
                self.assertTrue(10-1e-4 <= words["X"] <= 30+1e-4)
                self.assertTrue(10-1e-4 <= words["Y"] <= 30+1e-4)

    def test_actual_orca_metadata_contract_and_registration(self):
        import types, runpy, tomllib
        file = ROOT / "dist/arc_overhang.py"
        source = file.read_text()
        block = source.split("# /// script\n",1)[1].split("# ///",1)[0]
        metadata = tomllib.loads("\n".join(line[2:] for line in block.splitlines()))
        self.assertEqual(metadata["tool"]["orcaslicer"]["plugin"]["version"], a.VERSION)
        self.assertEqual(len(metadata["dependencies"]), 2)
        calls = []
        class Capability:
            config = "{}"
            fail_save = False
            override = None
            def get_config(self): return self.override if self.override is not None else self.config
            def save_config(self, config):
                if self.fail_save: return False
                self.config = config
                return True
            def post_message(self, data):
                if not hasattr(self, "messages"): self.messages = []
                self.messages.append(data)
        result = types.SimpleNamespace(success=lambda *v:("success",v), skipped=lambda *v:("skipped",v),
                                       failure=lambda *v:("failure",v))
        host = types.ModuleType("orca")
        host.base = type("Base", (), {})
        host.plugin = lambda cls:cls
        host.register_capability = calls.append
        host.slicing = types.SimpleNamespace(SlicingPipelineCapabilityBase=Capability, Step=types.SimpleNamespace(psGCodePostProcess=99))
        host.pages = types.SimpleNamespace(PagesPluginCapabilityBase=Capability)
        host.ExecutionResult = result
        host.PluginResult = types.SimpleNamespace(FatalError="fatal")
        with patch.dict(sys.modules, {"orca":host}):
            namespace = runpy.run_path(str(file), run_name="plugin_test")
        namespace["ArcOverhangPlugin"]().register_capabilities()
        self.assertEqual(len(calls), 2)
        capability = calls[0]()
        self.assertEqual(capability.get_name(), "Arc Overhang")
        self.assertEqual(capability.get_default_config(), a.DEFAULTS)
        self.assertTrue(capability.has_config_ui())
        self.assertIn("window.orca.saveConfig", capability.get_config_ui())
        self.assertEqual(capability.execute(types.SimpleNamespace(step=0))[0], "skipped")
        ctx = types.SimpleNamespace(step=99, config_value=lambda key:None, gcode_path="missing-file.gcode", cancelled=lambda:False)
        self.assertEqual(capability.execute(ctx)[0], "failure")
        page = calls[1]()
        self.assertEqual(page.get_name(), "Arc Overhang")
        self.assertIn("window.orca.onMessage", page.get_ui())
        capability.on_load()
        page.on_message({"action":"read","request_id":1})
        self.assertEqual(page.messages[-1]["config"], a.DEFAULTS)
        page.on_message({"action":"save","request_id":2,"config":{"arc_speed_mm_s":10}})
        self.assertTrue(page.messages[-1]["ok"])
        self.assertEqual(__import__("json").loads(capability.get_config())["arc_speed_mm_s"],10)
        page.on_message({"action":"save","request_id":3,"config":{"arc_speed_mm_s":0}})
        self.assertFalse(page.messages[-1]["ok"])
        self.assertEqual(__import__("json").loads(capability.get_config())["arc_speed_mm_s"],10)
        capability.fail_save = True
        page.on_message({"action":"save","request_id":4,"config":{"arc_speed_mm_s":12}})
        self.assertFalse(page.messages[-1]["ok"])
        capability.fail_save = False
        capability.override = '{"arc_speed_mm_s":3}'
        page.on_message({"action":"save","request_id":5,"config":{"arc_speed_mm_s":12}})
        self.assertTrue(page.messages[-1]["preset_override_active"])
        self.assertEqual(page.messages[-1]["config"]["arc_speed_mm_s"],3)
        capability.override = None
        capability.on_unload()
        page.on_message({"action":"read","request_id":6})
        self.assertFalse(page.messages[-1]["ok"])
        page.on_message(None)
        page.on_message({"action":"read","request_id":"invalid"})


    def test_missing_settings_and_unsupported_modes(self):
        for source in (fixture().replace("; nozzle_diameter = 0.4\n",""),
                       fixture().replace("M83","M83\nG20")):
            with self.subTest(source=source[:60]), self.assertRaises(a.UnsupportedGCode):
                a.process_text(source)
        source = fixture().replace("; nozzle_diameter = 0.4",
                                   "; nozzle_diameter = 0.4;0.6")
        source = source.replace("; filament_diameter = 1.75",
                                "; filament_diameter = 1.75;2.85")
        self.assertEqual(a.printer_settings(source.splitlines(), tool_index=1)["nozzle_diameter"], 0.6)
        output, report = a.process_text(source)
        self.assertEqual(report["replaced_features"], 1, report)

    def test_single_nonzero_tool_index_is_supported(self):
        source = fixture().replace("G90\nM83", "T1\nT1\nG90\nM83")
        output, report = a.process_text(source)
        self.assertEqual(report["replaced_features"], 1)
        self.assertIn(a.MARKER, output)

    def test_multiple_physical_tools_use_selected_material_and_preserve_switches(self):
        source = fixture().replace("G90\nM83", "T0\nG90\nM83")
        source = source.replace("; FEATURE: Bridge", "T1\n; FEATURE: Bridge")
        source = source.replace("; FEATURE: Sparse infill", "T0\n; FEATURE: Sparse infill")
        resolved = {
            "nozzle_diameter": [0.4, 0.6],
            "filament_diameter": [1.75, 2.85],
            "outer_wall_line_width": [0.42, 0.62],
            "filament_flow_ratio": [1.0, 0.9],
        }
        selected = a.printer_settings(source.splitlines(), resolved, tool_index=1)
        self.assertEqual(selected["nozzle_diameter"], 0.6)
        self.assertEqual(selected["filament_diameter"], 2.85)
        output, report = a.process_text(source, resolved=resolved)
        self.assertEqual(report["replaced_features"], 1, report)
        self.assertIn("T1\n; FEATURE: Bridge", output)
        self.assertTrue(output.endswith("T0\n; FEATURE: Sparse infill" + fixture().split("; FEATURE: Sparse infill",1)[1]))
        arc_block = output.split(a.MARKER + "BEGIN",1)[1].split(a.MARKER + "END",1)[0]
        arc_lines = arc_block.splitlines()
        first_extrusion_index = next(i for i,line in enumerate(arc_lines)
                                     if a.command(line)[0] == "G1"
                                     and "X" in a.command(line)[1] and "Y" in a.command(line)[1]
                                     and a.command(line)[1].get("E", 0) > 0)
        first_extrusion = a.command(arc_lines[first_extrusion_index])[1]
        travel_words = next(a.command(line)[1] for line in reversed(arc_lines[:first_extrusion_index])
                            if a.command(line)[0] == "G1" and "X" in a.command(line)[1]
                            and "Y" in a.command(line)[1] and "E" not in a.command(line)[1])
        distance = ((first_extrusion["X"] - travel_words["X"])**2
                    + (first_extrusion["Y"] - travel_words["Y"])**2)**0.5
        expected_e_per_mm = (0.6 / 2.85) ** 2 * 1.35 * 0.9
        self.assertAlmostEqual(first_extrusion["E"], distance * expected_e_per_mm, places=6)

    def test_seam_gap_is_closed_for_support_detection(self):
        source = "G90\nM83\n; CHANGE_LAYER\nG1 Z0.2\n"
        source += "; FEATURE: Outer wall\nG1 X0 Y0.04\nG1 X20 Y0 E1\nG1 X20 Y20 E1\nG1 X0 Y20 E1\nG1 X0 Y0.08 E1\n"
        shape = a.layer_shape(a.parse(source.splitlines(True)), 0.42)
        self.assertGreater(shape.area, 399)


    def test_tool_change_inside_bridge_feature_is_preserved(self):
        source = fixture().replace("G1 X29.5 Y10.5 E0.15 F1200",
                                   "G1 X29.5 Y10.5 E0.15 F1200\nT1", 1)
        output, report = a.process_text(source)
        self.assertEqual(report["replaced_features"], 0)
        self.assertIn("T1\nG1 X29.5 Y10.9", output)

    def test_bambu_markers_do_not_hide_real_multimaterial_switches(self):
        source = fixture().replace("G90\nM83", "T1000\nT0\nG90\nM83")
        source = source.replace("; FEATURE: Bridge", "T1\n; FEATURE: Bridge")
        source = source.replace("; FEATURE: Sparse infill", "T0\nT255\n; FEATURE: Sparse infill")
        resolved = {
            "nozzle_diameter": [0.4, 0.6],
            "filament_diameter": [1.75, 2.85],
        }
        output, report = a.process_text(source, resolved=resolved)
        self.assertEqual(report["replaced_features"], 1, report)
        self.assertIn("T1\n; FEATURE: Bridge", output)
        self.assertIn("T0\nT255\n; FEATURE: Sparse infill", output)

    def test_bambu_virtual_tool_markers_are_not_physical_tool_changes(self):
        source = fixture().replace("G90\nM83", "T1000\nT0\nG90\nM83") + "T255\n"
        output, report = a.process_text(source)
        self.assertEqual(report["replaced_features"], 1)
        self.assertTrue(output.endswith("T255\n"))


    def test_full_circle_and_radius_arc_input(self):
        full = "G90\nM83\n; CHANGE_LAYER\nG1 Z0.2\n; FEATURE: Outer wall\nG1 X20 Y10\nG3 X20 Y10 I-10 J0 E1\n"
        move = a.parse(full.splitlines(True))[0].moves[-1]
        line = a.segment(move)
        self.assertTrue(line.is_ring)
        self.assertAlmostEqual(line.length, 20*a.math.pi, delta=0.1)
        for code in ("G2","G3","G02","G03"):
            text = f"G90\nM83\n; CHANGE_LAYER\nG1 Z0.2\n; FEATURE: Outer wall\nG1 X0 Y0\n{code} X20 Y0 R10 E1\n"
            line = a.segment(a.parse(text.splitlines(True))[0].moves[-1])
            self.assertAlmostEqual(line.length,10*a.math.pi,delta=0.1)

    def test_progress_message_does_not_block_injection(self):
        source = fixture().replace("G1 X29.5 Y10.5 E0.15 F1200", "M73 P10 R10\nG1 X29.5 Y10.5 E0.15 F1200")
        self.assertIn("M73 P10 R10",source)
        output,report = a.process_text(source)
        self.assertEqual(report["replaced_features"],1)
        self.assertEqual(output.count("M73 P10 R10"),1)

    def test_scarf_projection_has_correct_hole_topology(self):
        source = "G90\nM83\n; CHANGE_LAYER\nG1 Z0.2\n"
        # Complete contour with a retraced seam tail.
        source += ring(0,0,20,20) + "G1 X5 Y0 E0.01\n" + ring(5,5,10,10)
        shape = a.layer_shape(a.parse(source.splitlines(True)),0.42)
        self.assertGreater(shape.area,374)
        self.assertLess(shape.area,376)
        self.assertFalse(shape.contains(a.Point(7,7)))

    def test_utf8_bom_file_is_supported(self):
        with tempfile.TemporaryDirectory(dir=ROOT) as folder:
            path=Path(folder)/"bom.gcode"
            path.write_bytes(b"\xef\xbb\xbf"+fixture().encode("utf-8"))
            report=a.process_file(path)
            self.assertEqual(report["replaced_features"],1)


    def test_xy_extrusion_repays_wipe_retraction(self):
        source = "G90\nM83\n; CHANGE_LAYER\nG1 Z0.2\n; FEATURE: Outer wall\nG1 X0 Y0\nG1 E-.4\nG1 X1 Y0 E.7\n"
        last = a.parse(source.splitlines(True))[0].moves[-1]
        self.assertAlmostEqual(last.before.retracted,.4)
        self.assertEqual(last.after.retracted,0)

    def test_submicron_wipe_rounding_is_not_a_permanent_debt(self):
        source = "G90\nM83\n; CHANGE_LAYER\nG1 Z0.2\n; FEATURE: Outer wall\nG1 X0 Y0\nG1 E-.40027\nG1 E.4\n"
        self.assertEqual(a.parse(source.splitlines(True))[0].moves[-1].after.retracted,0)
        source = fixture().replace("G92 E0", "G92 E0\nG1 E-.40027\nG1 E.4")
        output,report=a.process_text(source)
        self.assertEqual(report["replaced_features"],1)
        self.assertIn(a.MARKER,output)

    def test_real_unrecovered_retraction_remains_protected(self):
        cfg=a.configuration()
        printer=a.printer_settings(fixture().splitlines())
        with self.assertRaises(a.UnsupportedGCode):
            a.emit_arcs([a.LineString([(0,0),(1,0)])],
                        a.State(x=0,y=0,retracted=.4),
                        a.State(x=1,y=0,retracted=0),cfg,printer)

if __name__ == "__main__":
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(Tests)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    if result.wasSuccessful():
        out, report = a.process_text(fixture(), {"minimum_coverage_percent":80})
        (ROOT / "synthetic_before.gcode").write_text(fixture())
        (ROOT / "synthetic_after.gcode").write_text(out)
        print(report)
    sys.exit(not result.wasSuccessful())
